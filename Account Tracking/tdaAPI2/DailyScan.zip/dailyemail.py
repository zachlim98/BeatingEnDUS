import pandas as pd
from finviz.screener import Screener
from tda import auth, client
import json
import telegram_send
from bs4 import BeautifulSoup
import requests
import dataframe_image as dfi

### TDA ACCOUNT ACCESS

#gain access to TDA account
token_path = R'token.pickle'
api_key = 'DRSMU4TL964FO3QNBQHVL78X9SUPGGIL@AMER.OAUTHAP'
redirect_uri = "http://localhost"
try:
    c = auth.client_from_token_file(token_path, api_key)
except FileNotFoundError:
    from selenium import webdriver
    with webdriver.Chrome() as driver:
        c = auth.client_from_login_flow(
            driver, api_key, redirect_uri, token_path)

### TDA POSITIONS RETRIVAL

# set account to pull positions
p = client.Client.Account.Fields("positions") 
# pull positions as json 
a = c.get_accounts(fields=p)
assert a.status_code == 200, a.raise_for_status()
data = a.json()

#normalize to form df and then pull raw positions from json
positions_df = pd.json_normalize(data[0])
raw_positions = pd.json_normalize(positions_df["securitiesAccount.positions"][0])

dfi.export(raw_positions[["currentDayProfitLossPercentage", "instrument.symbol"]],"positions.jpeg")
current_positions = open(R".\positions.jpeg", "rb") 

### FINVIZ SCANNING

# apply scans
filter = ["an_recom_buybetter","cap_midover","sh_avgvol_o2000","sh_curvol_o5000","sh_opt_option","sh_price_o10","ta_pattern_horizontal","ta_perf_ddown"]
daily_scan = Screener(filters=filter, table="Overview")

#convert to df
scanned_df = pd.json_normalize(daily_scan.data)
dfi.export(scanned_df.sort_values(["Sector","Change"], ascending=False),"finviz.jpeg")
recco  = open(R".\finviz.jpeg", "rb") 

#convert to watchlist textfile
f=open('DailyScan.txt','w')
for ele in scanned_df["Ticker"].to_list():
    f.write(ele+',')
f.close()

watchlist = open(R".\DailyScan.txt", 'rb')

### Options Scanning

#create list to attach df objects
rando_data = []
#define parameters
para = c.Options 

#loop to scan through all tickers to find good options
for i in scanned_df["Ticker"].to_list():
    try: 
        chains = c.get_option_chain(symbol=i, contract_type=para.ContractType.PUT, strategy=para.Strategy.VERTICAL, option_type=para.Type.STANDARD)
        initial = pd.json_normalize(chains.json(), record_path="monthlyStrategyList")
        filtered = initial[initial["daysToExp"] < 45]
        spreads = pd.json_normalize(filtered["optionStrategyList"].explode())
        output = spreads.loc[(spreads["strategyBid"]>1.20) & (spreads["primaryLeg.range"]=="OTM")]
        rando_data.append(output)

    except:
        pass

#create dataframe
optins_data = pd.concat(rando_data)
#prepare for telegram sending
dfi.export(optins_data,"chains.jpeg")
possible  = open(R".\chains.jpeg", "rb") 

### Bible Verse Sending

#create verse otd function
def verse_otd():    
    URL = "https://www.bible.com/en-GB"
    page = requests.get(URL)

    soup = BeautifulSoup(page.content, 'html.parser')
    verse = soup.find('p', class_="votd-verse").text.strip()
    ref = soup.find('p', class_="votd-ref").text.strip()
    return(verse, ref)

verse =  verse_otd()

### SENDING TELEGRAM MESSAGE

telegram_send.send(messages=["Good morning Zach! Here's the verse for the day", verse, 
"your friendly reminder that you are loved and that you don't have to defend yourself and take things personally!"], 
images=[current_positions, 
recco, 
possible], 
files = [watchlist], 
conf=R".\telegramtoken.pickle",
parse_mode="markdown")


# yag = yagmail.SMTP("trashmail.imtrash@gmail.com","trash6969")
# name = ["Good morning Zach! Here's the verse for the day ", verse, 
# "This is your friendly reminder that you are loved and that you don't have to defend yourself and take things personally!",  
# "\n Your positions:\n", current_positions, "\n Finviz scan:\n", recco, "\n Option Chains:\n", possible]
# yag.send(to='zacharylim98@gmail.com', subject="Your Morning Email", contents=name)

